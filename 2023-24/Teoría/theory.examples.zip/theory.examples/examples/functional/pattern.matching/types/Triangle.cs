﻿using System;
using System.Collections.Generic;

namespace TPP.Functional.PatternMatching {

    class Triangle {
        public int X { get; set; }
        public int Y { get; set; }
        public int Base { get; set; }
        public int Height { get; set; }
    }

}
