﻿using System;
using System.Collections.Generic;

namespace TPP.Functional.PatternMatching {

    public class Square {
        public int X { get; set; }
        public int Y { get; set; }
        public int Side { get; set; }
    }

}
