﻿using System;
using System.Collections.Generic;

namespace TPP.Functional.PatternMatching {

    public class Circle {
        public int X { get; set; }
        public int Y { get; set; }
        public int Radius { get; set; }
    }

}
