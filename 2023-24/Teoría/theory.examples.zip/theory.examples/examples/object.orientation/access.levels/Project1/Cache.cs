﻿namespace myData
{
	public class Cache
	{
		public void Put(string key, string value) { }
		private void Clear() { }
		protected void Grow() { }
		internal double HitRate() { return 0; }
	}
}
