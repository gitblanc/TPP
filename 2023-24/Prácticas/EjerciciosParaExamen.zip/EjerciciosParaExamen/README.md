En este proyecto he realizado todos los ejercicios de clase junto con algunos que se me han ido ocurriendo para practicar para el examen de TPP (para el primer parcial).
En este documento explico brevemente la estructura del mismo.

## Estructura seguida

Hay dos proyectos:
- La aplicación de consola (el Program), donde llamo a todos los ejercicios
- El modelo de clases (Modelo), donde están todas las clases necesarias para las factorias y demás (Persona, Libro, Angulo...)

## Cómo identificar los ejercicios

Voy poniendo este formato: EjercicioX_PY, donde X es el número de ejercicio de la Práctica Y

Por último, recalcar que llamo a todos desde el Program como dije antes, y el resultado de cada Ejercicio se muestra en verde en la consola.


```
       _                        
       \`*-.                    
        )  _`-.                 
       .  : `. .                
       : _   '  \               
       ; *` _.   `*-._          
       `-.-'          `-.       
         ;       `       `.     
         :.       .        \    
         . \  .   :   .-'   .   
         '  `+.;  ;  '      :   
         :  '  |    ;       ;-. 
         ; '   : :`-:     _.`* ;
      .*' /  .*' ; .*`- +'  `*' gatete
      `*-*   `*-*  `*-*'
```