﻿using System;
using ModeloClases;

namespace ListaEnlazada01
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Para la LinkedList y la Pila mira los tests anda...");

            LinqQueries.Consulta1();
            LinqQueries.Consulta2();
            LinqQueries.Consulta3();
            LinqQueries.Consulta4();
            LinqQueries.Consulta5();
        }
    }
}
