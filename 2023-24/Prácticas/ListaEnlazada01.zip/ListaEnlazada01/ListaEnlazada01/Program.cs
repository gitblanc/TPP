﻿using System;
using ModeloClases;

namespace ListaEnlazada01
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Mira los tests anda...");
        }
    }
}
