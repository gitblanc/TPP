﻿using System;

namespace EjercicioMasterWorker
{
    class Program
    {
        /// <summary>
        /// A partir del Master Worker de la entrega obligatoria, prueba las siguientes modificaciones:
        /// -Los workers almacenarán en una lista "Resultado", los valores que sean superiores a la cantidad buscada.
        ///     - No admitirá duplicados.
        ///     - La lista Resultado la pasa el Master a los workers y DEBE SER LA MISMA PARA TODOS LOS WORKERS.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {


        }
    }
}
