﻿
namespace TPP.Seminarios.Concurrente.Seminario6 {

    /// <summary>
    /// Cada uno de los tenedores disponibles
    /// </summary>
    class Tenedor {

        /// <summary>
        /// Número de tenedor
        /// </summary>
        private int numero;

        public Tenedor(int numero) {
            this.numero = numero;
        }

    }
}
