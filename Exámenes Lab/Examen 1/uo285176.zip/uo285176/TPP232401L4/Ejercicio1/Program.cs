﻿using System;

namespace Ejercicio1
{
    internal class Program
    {
        static void Main()
        {

        }
  
    }


}
