﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    //Genérica
    public class ListaEncriptada<T>
    {
        private LinkedList<T> _list;
        private Func<T, T> _encriptar, _desencriptar;

        public ListaEncriptada(Func<T, T> encriptar, Func<T, T> desencriptar)
        {
            //precondicion -> no pueden ser nulos
            if (encriptar == null || desencriptar == null)
                throw new ArgumentException("Los delegados no pueden ser nulos");

            _encriptar = encriptar;
            _list = new LinkedList<T>();
            _desencriptar = desencriptar;
        }

        public T Insertar(T elem)
        {
            T res = _encriptar(elem);
            _list.Add(res);
            return res;
        }

        public T GetElemento(int pos)
        {
            //precondición -> debe ser una posición válida (> 0 y < NumberOfElems)
            if (pos < 0 || pos > Tam())
                throw new ArgumentException("La posición no es válida");

            return _desencriptar(_list.ElementAt(pos));
        }

        public int Tam()
        {
            return _list.NumberOfElements;
        }
    }
}
