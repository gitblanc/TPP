using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ejercicio2;
using System;

namespace TestEj2
{
    [TestClass]
    public class TestEj2
    {
        [TestMethod]
        public void TestMethod1()
        {
            string[] c1 = { "patata", "cebollino", "puerro" };
            int[] c2 = { 0, 1, 2, 3, 4, 5, 6 };
            int desplazamiento = 4;
            var generador = Program.Generador(desplazamiento, c1, c2).GetEnumerator();

            Assert.IsTrue(generador.MoveNext());

            Assert.AreEqual(("patata", 3), generador.Current);
            Assert.IsTrue(generador.MoveNext());
            Assert.AreEqual(("cebollino", 0), generador.Current);
            Assert.IsTrue(generador.MoveNext());
            Assert.AreEqual(("puerro", 4), generador.Current);
            Assert.IsFalse(generador.MoveNext());

            //Si la c2 no tiene elementos -> se hace un yield break
            int[] c3 = { };
            var generador2 = Program.Generador(desplazamiento, c1, c3).GetEnumerator();
            Assert.IsFalse(generador2.MoveNext());
        }
    }
}
