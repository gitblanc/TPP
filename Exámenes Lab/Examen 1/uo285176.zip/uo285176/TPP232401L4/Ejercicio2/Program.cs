﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Ejercicio2
{
    public static class Program
    {
        static void Main()
        {
            char[] c1 = { 'a', 'b', 'c' };
            int[] c2 = { 0, 1, 2, 3, 4, 5, 6 };
            int desplazamiento = 3;
            var generador = Generador(desplazamiento, c1, c2).GetEnumerator();

            generador.MoveNext();
            for (int i = 0; i < c1.Length; i++)
            {
                Console.WriteLine(generador.Current);
                generador.MoveNext();
            }
        }

        public static IEnumerable<(T, Q)> Generador<T, Q>(int desplazamiento, IEnumerable<T> c1, IEnumerable<Q> c2)
        {
            var iterador1 = c1.GetEnumerator();
            var iterador2 = c2.GetEnumerator();

            while (iterador1.MoveNext())
            {
                //¿Qué pasa si c2 no tiene elementos?
                var cont = 0;
                while (cont < desplazamiento)//Usamos el desplazamiento
                {
                    if (!iterador2.MoveNext())
                        //Si no quedan más elementos se resetea;
                        if (cont == 0)
                        {
                            yield break;
                        }
                        else//Hay elementos -> se reinicia
                        {
                            iterador2.Reset();
                            iterador2.MoveNext();
                        }
                    cont += 1;
                }
                yield return (iterador1.Current, iterador2.Current);
            }
        }
    }
}
