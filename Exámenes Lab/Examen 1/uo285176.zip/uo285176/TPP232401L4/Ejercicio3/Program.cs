﻿using System;
using System.Collections.Generic;

namespace Ejercicio3
{
    internal static class Program
    {
        static void Main()
        {

            var list1 = new List<int>() { 1, 3, 4, 6 };
            var list2 = new List<int>() { 1, 2, 4, 6 };

            var emparejar = Emparejar(list1, list2, c1 => c1, c2 => c2).GetEnumerator();
            emparejar.MoveNext();

            for (int i = 0; i < list1.Count; i++)
            {
                Console.WriteLine(emparejar.Current);
                emparejar.MoveNext();
            }
        }

        //dice implementese en IEnumerable -> extensor
        private static IEnumerable<(T, T)> Emparejar<T>(this IEnumerable<T> c1, IEnumerable<T> c2, Func<T, T> GetClaveElemC1, Func<T, T> GetClaveElemC2)
        {
            var iterador1 = c1.GetEnumerator();
            var iterador2 = c2.GetEnumerator();
            while (iterador1.MoveNext() && iterador2.MoveNext())
            {
                if (GetClaveElemC1(iterador1.Current).Equals(GetClaveElemC2(iterador2.Current)))
                    yield return (iterador1.Current, iterador2.Current);
            }
        }

        //Versión currificada
        private static IEnumerable<Func<Func<T, T>, (T, T)>> EmparejarB<T>(this IEnumerable<T> c1, IEnumerable<T> c2, Func<T, T> GetClaveElemC1)//, Func<T, T> GetClaveElemC2)
        {
            //return GetClaveElemC2 =>
            //{
            //    var iterador1 = c1.GetEnumerator();
            //    var iterador2 = c2.GetEnumerator();
            //    while (iterador1.MoveNext() && iterador2.MoveNext())
            //    {
            //        if (GetClaveElemC1(iterador1.Current).Equals(GetClaveElemC2(iterador2.Current)))
            //            yield return (iterador1.Current, iterador2.Current);
            //    }
            //};
        }

    }
}
