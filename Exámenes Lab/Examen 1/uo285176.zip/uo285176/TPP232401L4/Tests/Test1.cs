using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Ejercicio1;

namespace Tests
{
    [TestClass]
    public class Test1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Func<string, string> encriptar = ROT1Encrypt;
            Func<string, string> desencriptar = ROT1Decrypt;
            try
            {
                var lista1 = new ListaEncriptada<string>(null, desencriptar);
                var lista2 = new ListaEncriptada<string>(encriptar, null);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            var lista = new ListaEncriptada<string>(encriptar, desencriptar);

            Assert.AreEqual(lista.Tam(), 0);
            Assert.AreEqual("qbubub", lista.Insertar("patata"));
            Assert.AreEqual(lista.Tam(), 1);
            Assert.AreEqual("dfcpmmjop", lista.Insertar("cebollino"));
            Assert.AreEqual(lista.Tam(), 2);

            Assert.AreEqual("patata", lista.GetElemento(0));
            Assert.AreEqual("cebollino", lista.GetElemento(1));
        }

        private static string ROT1Encrypt(string s)
        {
            var res = "";
            foreach (char elem in s)
            {
                res += (char)(elem + 1);
            }
            return res;
        }

        private static string ROT1Decrypt(string s)
        {
            var res = "";
            foreach (char elem in s)
            {
                res += (char)(elem - 1);
            }
            return res;
        }
    }
}
