﻿using System;
using System.Collections.Generic;
using System.Linq;
using Modelo;

namespace Ejercicio4
{

    internal class Program
    {
        private static Model modelo = new Model();


        static void Main()
        {
            ConsultaA();
            ConsultaB();
        }

        private static void ConsultaA()
        {
            Console.WriteLine("---Consulta A---");
            //Media de edad de los empleados agrupados por oficina
            //Mostrar Número;Edificio;media_edad_empleados_oficina
            var result = modelo.Employees.GroupBy(e => e.Office).Select(grupo => new
            {
                Edificio = grupo.Key.Building,
                Numero = grupo.Key.Number,
                Media = grupo.Average(e => e.Age)
            }).Select(a => $"{a.Numero};{a.Edificio};{a.Media}");

            Show(result);
        }

        private static void ConsultaB()
        {
            Console.WriteLine("---Consulta B---");
            //Duración de llamadas cuyos teléfonos de origen y destino no pertenecen a empleados
            var result = modelo.PhoneCalls.Where(ll => !modelo.Employees.Any(e => e.TelephoneNumber.Equals(ll.SourceNumber) ||
                e.TelephoneNumber.Equals(ll.DestinationNumber)
            )).Select(ll => $"{ll.SourceNumber} to {ll.DestinationNumber}: {ll.Seconds}");

            Show(result);
        }

        private static void Show<T>(IEnumerable<T> colección)
        {
            foreach (var item in colección)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Elementos en la colección: {0}.", colección.Count());
        }
    }


}
